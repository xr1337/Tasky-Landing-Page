## Tasky: Enhanced Productivity Widgets for Apple Reminders

Tasky is a widget app built for Apple Reminders.

## Features
* 6 Home screen widgets
* 4 Lock screen widgets
* Daily progress bar
* Weekly bar chart
* Font and color customization

## For Whom?
Apple Reminders productivity enthusiasts.

## Pricing
Tasky is freemium with one free widget. Purchase options:
- Lifetime: $5.99
- Yearly: $3.99

## My story
Apple Reminders is great, but its interactive widgets often cause me to
accidentally mark tasks as done, and there's no way to turn them off.
I kept missing things like taking out the trash.

So, I created Tasky to fix my fat finger problem. Along the way, I added
graph and bar chart widgets to keep me motivated and on track.
